#include "project.h"

void initComp();
float readTemp();

/* [] END OF FILE */
