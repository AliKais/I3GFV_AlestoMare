#include "project.h"

CY_ISR_PROTO(isr_UART_rx);

/* [] END OF FILE */
